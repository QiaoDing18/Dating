$(document).ready(function(){
	showSide();
});
// 菜单栏的展开
function showSide(){
	// 导航栏一
	$(".head-1").click(function(){
		var display = $(".nav-frame").css("display");
		if(display == "block"){
			$(".nav-frame1").css("display", "block");
			$(".nav-frame1").find(".nav-child").each(function(){
				$(this).css("display", "block");
			});
			return;
		}
		$(".nav-frame").toggle("fast");
		$(this).css("display", "none");
		$(".none-1").css("display", "block");

		$(".nav-frame1").css("display", "block");
		$(".nav-frame1").find(".nav-child").each(function(){
			$(this).css("display", "block");
		});
	});
	$(".none-1").click(function(){
		$(".nav-frame").toggle("fast");
		$(this).css("display", "none");
		$(".head-1").css("display", "block");
	});


	


	$(".double").find("div").each(function(){
		$(this).mouseenter(function(){
			$(this).find("p").each(function(){
				$(this).toggle("fast");
			});
		});
	});
	$(".double").find("div").each(function(){
		$(this).mouseleave(function(){
			$(this).find("p").each(function(){
				$(this).toggle("fast");
			});
		});
	});
}

$(function(){
	$('.panel').css({'height': $(window).height()});
	$.scrollify({
		section: '.panel'
	});
});